import pymysql
import json
from collections import Counter
from typing import List, Dict, Optional

def get_db_connection():
    """Establish a connection to the MySQL database."""
    return pymysql.connect(
        host='localhost',
        user='root',  # Replace with your DB username
        password='',  # Replace with your DB password
        database='baseprojet',  # Replace with your DB name
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def get_user_reservations(user_id: Optional[int] = None) -> List[Dict]:
    """Fetch reservations for a user or for NULL user_id if user_id is None."""
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            if user_id is not None:
                sql = """
                    SELECT e.id, e.category, e.name, e.date, e.price, e.image_url
                    FROM chaise c
                    JOIN evenements e ON c.event_id = e.id
                    WHERE c.statut = 'reserve' AND c.id_user = %s
                    GROUP BY e.id
                """
                cursor.execute(sql, (user_id,))
            else:
                sql = """
                    SELECT e.id, e.category, e.name, e.date, e.price, e.image_url
                    FROM chaise c
                    JOIN evenements e ON c.event_id = e.id
                    WHERE c.statut = 'reserve' AND c.id_user IS NULL
                    GROUP BY e.id
                """
                cursor.execute(sql)
            return cursor.fetchall()
    finally:
        connection.close()
def get_events_by_category(category: str) -> List[Dict]:
    """Fetch events for a specific category, ordered by date descending."""
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            sql = """
                SELECT id, name, price, image_url AS imageUrl
                FROM evenements
                WHERE category = %s
                ORDER BY date DESC
                LIMIT 1
            """
            cursor.execute(sql, (category,))
            return cursor.fetchall()
    finally:
        connection.close()

def generate_recommendations(user_id: Optional[int] = None) -> List[Dict]:
    """
    Generate event recommendations based on user reservations.
    For new users (no reservations or user_id=None), recommend one event per category.
    """
    categories = ['sportif', 'culturel', 'culinaire', 'musique', 'charite']
    recommendations = []

    # Fetch user reservations
    reservations = get_user_reservations(user_id)

    if not reservations:
        # New user: recommend one event from each category
        for category in categories:
            events = get_events_by_category(category)
            if events:
                recommendations.append({
                    'category': category,
                    'event': events[0],
                    'image': events[0]['imageUrl']  # Use event-specific image URL
                })
    else:
        # Existing user: recommend based on category preferences
        category_counts = Counter(res['category'] for res in reservations)
        sorted_categories = [cat for cat, _ in category_counts.most_common()]

        # Recommend top 5 events (prioritize user's preferred categories)
        for category in sorted_categories + [c for c in categories if c not in sorted_categories]:
            if len(recommendations) >= 5:
                break
            events = get_events_by_category(category)
            if events:
                recommendations.append({
                    'category': category,
                    'event': events[0],
                    'image': events[0]['imageUrl']  # Use event-specific image URL
                })

    return recommendations
def main(user_id: Optional[int] = None):
    """Main function to generate and output recommendations as JSON."""
    try:
        recommendations = generate_recommendations(user_id)
        print(json.dumps({
            'success': True,
            'recommendations': recommendations
        }))
    except Exception as e:
        print(json.dumps({
            'success': False,
            'error': str(e)
        }))

if __name__ == '__main__':
    import sys
    user_id = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else None
    main(user_id)